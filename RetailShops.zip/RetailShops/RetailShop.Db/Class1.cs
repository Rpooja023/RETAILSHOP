﻿namespace RetailShop.Db
{
    public class Class1
    {

    }
}