namespace RetailShops.XunitTest
{
    public class Sampledata
    {
        [Fact]
        public void Test1()
        {
          
        }
    }
}