﻿namespace RetailShops.Service
{
    public class Class1
    {

    }
}