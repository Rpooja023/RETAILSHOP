﻿namespace RetailShops.Models
{
    public class Class1
    {

    }
}